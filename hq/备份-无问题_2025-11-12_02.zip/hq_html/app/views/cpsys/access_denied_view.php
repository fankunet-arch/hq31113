<div class="container text-center mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h1 class="display-1 text-danger"><i class="bi bi-shield-slash-fill"></i></h1>
                    <h2 class="card-title mt-4">访问被拒绝</h2>
                    <p class="card-text text-white-50">
                        抱歉，您的角色权限不足，无法访问此页面。
                    </p>
                    <a href="index.php" class="btn btn-primary mt-3">返回仪表盘</a>
                </div>
            </div>
        </div>
    </div>
</div>