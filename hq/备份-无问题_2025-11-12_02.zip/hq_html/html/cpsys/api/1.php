<?php
// 这将生成一个与您系统兼容的 Bcrypt 哈希值
echo password_hash("8888", PASSWORD_BCRYPT);
?>